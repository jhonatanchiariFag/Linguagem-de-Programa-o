package trabalho2b;

import java.util.ArrayList;

public class Restaurante {
    private ArrayList<Funcionario> funcionarios;
    private ArrayList<Mesa> mesas;
    private ArrayList<ItemCardapio> cardapio;
    private ArrayList<Pedido> pedidos;
    private double faturamentoTotal;
    private ArrayList<Double> faturamentoPorMesa; 
    public Restaurante() {
        this.funcionarios = new ArrayList<>();
        this.mesas = new ArrayList<>();
        this.cardapio = new ArrayList<>();
        this.pedidos = new ArrayList<>();
        this.faturamentoTotal = 0.0;
        this.faturamentoPorMesa = new ArrayList<>(); 
    }

    public void cadastrarFuncionario(String nome, int idFuncionario, int cargoOpcao) {
        String cargo = "";
        switch (cargoOpcao) {
            case 1:
                cargo = "Garçom";
                break;
            case 2:
                cargo = "Cozinheiro";
                break;
            case 3:
                cargo = "Gerente";
                break;
            default:
                System.out.println("Opção inválida.");
                return;
        }
        Funcionario funcionario = new Funcionario(nome, idFuncionario, cargo);
        this.funcionarios.add(funcionario);
    }

    public void cadastrarMesa(int numeroMesa, int capacidade) {
        Mesa mesa = new Mesa(numeroMesa, capacidade);
        this.mesas.add(mesa);
        while (faturamentoPorMesa.size() <= numeroMesa) {
            faturamentoPorMesa.add(0.0);
        }
    }

    public void adicionarItemCardapio(String nome, int codigo, double preco, boolean disponivel) {
        ItemCardapio item = new ItemCardapio(nome, codigo, preco, disponivel);
        this.cardapio.add(item);
    }

    public void registrarPedido(int numeroMesa, int idGarcom, ArrayList<Integer> codigosItens) {
        Mesa mesa = buscarMesa(numeroMesa);
        Funcionario garcom = buscarFuncionario(idGarcom);

        if (mesa == null || garcom == null || !garcom.getCargo().equals("Garçom")) {
            System.out.println("Erro ao registrar pedido, Função disponível somente para Garçons");
            return;
        }

        Pedido pedido = new Pedido(mesa, garcom);
        for (int codigo : codigosItens) {
            ItemCardapio item = buscarItemCardapio(codigo);
            if (item != null) {
                pedido.adicionarItem(item);
            }
        }
        mesa.ocuparMesa();
        pedidos.add(pedido);
        System.out.println("Pedido registrado com sucesso.");
    }

    public void fecharPedido(int numeroMesa) {
        Pedido pedido = buscarPedidoPorMesa(numeroMesa);
        if (pedido != null) {
            pedido.fecharPedido();
            faturamentoTotal += pedido.getValorTotal(); 
            int numeroMesaPedido = pedido.getMesa().getNumeroMesa();
            faturamentoPorMesa.set(numeroMesaPedido, faturamentoPorMesa.get(numeroMesaPedido) + pedido.getValorTotal());

            pedidos.remove(pedido);
        } else {
            System.out.println("Pedido não encontrado.");
        }
    }

    public void gerarRelatorioVendas() {
        for (Funcionario funcionario : funcionarios) {
            if (funcionario.getCargo().equals("Garçom")) {
                System.out.println(funcionario);
            }
        }
    }

    public void gerarRelatorioFaturamento() {
        System.out.println("Faturamento total: R$ " + faturamentoTotal);
        System.out.println("Faturamento por mesa:");
        
        for (int i = 0; i < faturamentoPorMesa.size(); i++) {
            System.out.println("Mesa " + i + ": R$ " + faturamentoPorMesa.get(i));
        }
    }

    private Mesa buscarMesa(int numeroMesa) {
        for (Mesa mesa : mesas) {
            if (mesa.getNumeroMesa() == numeroMesa) {
                return mesa;
            }
        }
        return null;
    }

    private Funcionario buscarFuncionario(int idFuncionario) {
        for (Funcionario funcionario : funcionarios) {
            if (funcionario.getIdFuncionario() == idFuncionario) {
                return funcionario;
            }
        }
        return null;
    }

    private ItemCardapio buscarItemCardapio(int codigo) {
        for (ItemCardapio item : cardapio) {
            if (item.getCodigo() == codigo) {
                return item;
            }
        }
        return null;
    }

    private Pedido buscarPedidoPorMesa(int numeroMesa) {
        for (Pedido pedido : pedidos) {
            if (pedido.getMesa().getNumeroMesa() == numeroMesa) {
                return pedido;
            }
        }
        return null;
    }
}
