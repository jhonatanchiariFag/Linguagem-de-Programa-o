package trabalho2b;

import java.util.ArrayList;

public class Pedido {
    private Mesa mesa;
    private Funcionario garcom;
    private ArrayList<ItemCardapio> itens;
    private double valorTotal;
    private boolean fechado; 

    
    public Pedido(Mesa mesa, Funcionario garcom) {
        this.mesa = mesa;
        this.garcom = garcom;
        this.itens = new ArrayList<>();
        this.valorTotal = 0.0;
        this.fechado = false; 

    }
    public void adicionarItem(ItemCardapio item) {
        if (item.isDisponivel()) { 
            this.itens.add(item);
            this.valorTotal += item.getPreco(); 
        } else {
            System.out.println("Item indisponível: " + item.getNome());
        }
    }

 
    public void fecharPedido() {
        if (!fechado) {
            this.garcom.registrarVendas(this.valorTotal);
            this.mesa.liberarMesa();
            this.fechado = true; 
            System.out.println("Pedido fechado. Valor total: R$ " + this.valorTotal);
        } else {
            System.out.println("O pedido já está fechado.");
        }
    }

    // Método para verificar se o pedido está fechado
    public boolean isFechado() {
        return fechado;
    }

    // Getters
    public Mesa getMesa() {
        return mesa;
    }

    public Funcionario getGarcom() {
        return garcom;
    }

    public ArrayList<ItemCardapio> getItens() {
        return itens;
    }

    public double getValorTotal() {
        return valorTotal;
    }

    // Método toString para representar o objeto como string
    @Override
    public String toString() {
        String detalhes = "Mesa: " + mesa.getNumeroMesa() + " | Garçom: " + garcom.getNome() + "\nItens do pedido:\n";
        
        // Percorre os itens do pedido e adiciona cada um à string
        for (int i = 0; i < itens.size(); i++) {
            ItemCardapio item = itens.get(i);
            detalhes += "- " + item.getNome() + " (R$ " + item.getPreco() + ")\n";
        }
        
        detalhes += "Valor Total: R$ " + valorTotal + 
                    "\nStatus: " + (fechado ? "Fechado" : "Aberto");
        
        return detalhes;
    }
}
