package trabalho2b;

public class ItemCardapio {
    private String nome;
    private int codigo;
    private double preco;
    private boolean disponivel;

    public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public double getPreco() {
		return preco;
	}

	public void setPreco(double preco) {
		this.preco = preco;
	}

	public boolean isDisponivel() {
		return disponivel;
	}

	public void setDisponivel(boolean disponivel) {
		this.disponivel = disponivel;
	}

	// Construtor
    public ItemCardapio(String nome, int codigo, double preco, boolean disponivel) {
        this.nome = nome;
        this.codigo = codigo;
        this.preco = preco;
        this.disponivel = disponivel;
    }

    // Método para atualizar disponibilidade
    public void atualizarDisponibilidade(boolean disponivel) {
        this.disponivel = disponivel;
    }

    // Método toString para representar o objeto como string
    @Override
    public String toString() {
        return "Código: " + codigo + " | Nome: " + nome + " | Preço: R$ " + preco + " | Disponibilidade: "
                + (disponivel ? "Disponível" : "Esgotado");
    }
}
