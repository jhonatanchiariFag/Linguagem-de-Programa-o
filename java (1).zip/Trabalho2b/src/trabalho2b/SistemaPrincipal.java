package trabalho2b;
import java.util.ArrayList;
import java.util.Scanner;

public class SistemaPrincipal {
    public static void main(String[] args) {
        Restaurante restaurante = new Restaurante();
        Scanner scanner = new Scanner(System.in);
        int opcao;

        do {
            System.out.println("\n--- Sistema de Gerenciamento de Restaurante ---");
            System.out.println("1. Cadastrar Funcionário");
            System.out.println("2. Cadastrar Mesa");
            System.out.println("3. Adicionar Item ao Cardápio");
            System.out.println("4. Registrar Pedido");
            System.out.println("5. Fechar Pedido");
            System.out.println("6. Gerar Relatório de Vendas por funcionário ");
            System.out.println("7. Gerar Relatório de Faturamento Geral");
            System.out.println("0. Sair");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();

            switch (opcao) {
                case 1:
                    System.out.print("Nome do Funcionário: ");
                    String nome = scanner.next();
                    System.out.print("ID do Funcionário: ");
                    int idFuncionario = scanner.nextInt();
                    System.out.println("Cargo: 1- Garçom, 2- Cozinheiro, 3- Gerente");
                    int cargoOpcao = scanner.nextInt();
                    restaurante.cadastrarFuncionario(nome, idFuncionario, cargoOpcao);
                    break;

                case 2:
                    System.out.print("Número da Mesa: ");
                    int numeroMesa = scanner.nextInt();
                    System.out.print("Capacidade da Mesa: ");
                    int capacidade = scanner.nextInt();
                    restaurante.cadastrarMesa(numeroMesa, capacidade);
                    break;

                case 3:
                    System.out.print("Nome do Item: ");
                    String nomeItem = scanner.next();
                    System.out.print("Código do Item: ");
                    int codigoItem = scanner.nextInt();
                    System.out.print("Preço do Item: ");
                    double preco = scanner.nextDouble();
                    System.out.print("Disponível (true/false): ");
                    boolean disponivel = scanner.nextBoolean();
                    restaurante.adicionarItemCardapio(nomeItem, codigoItem, preco, disponivel);
                    break;

                case 4:
                    System.out.print("Número da Mesa: ");
                    int numeroMesaPedido = scanner.nextInt();
                    System.out.print("ID do Garçom: ");
                    int idGarcom = scanner.nextInt();
                    System.out.print("Quantos itens no pedido? ");
                    int numItens = scanner.nextInt();
                    ArrayList<Integer> codigosItens = new ArrayList<>();
                    for (int i = 0; i < numItens; i++) {
                        System.out.print("Código do item " + (i + 1) + ": ");
                        codigosItens.add(scanner.nextInt());
                    }
                    restaurante.registrarPedido(numeroMesaPedido, idGarcom, codigosItens);
                    break;

                case 5:
                    System.out.print("Número da Mesa: ");
                    int numeroMesaFechar = scanner.nextInt();
                    restaurante.fecharPedido(numeroMesaFechar);
                    break;

                case 6:
                    restaurante.gerarRelatorioVendas();
                    break;

                case 7:
                    restaurante.gerarRelatorioFaturamento();
                    break;

                case 0:
                    System.out.println("Saindo...");
                    break;

                default:
                    System.out.println("Opção inválida.");
            }
            
        } while (opcao != 0);

        scanner.close();
    }
}
